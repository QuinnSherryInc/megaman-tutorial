/**
 * PLEASE DO NOT REMOVE THIS NOTICE!
 *
 * @template        This Phaser game was built using phaser-project-template-es6 (https://github.com/yandeu/phaser-project-template-es6)
 * @author          Yannick Deubel (https://github.com/yandeu)
 * @copyright       2019 Yannick Deubel
 * @license         {@link https://github.com/yandeu/phaser-project-template-es6/blob/master/LICENSE|MIT License}
 */

// Of course you can remove it if you really want to, but it would be nice if you would leave it there :)

console.log(
  '%c %c %c %c %c Built using phaser-project-template-es6 %c https://github.com/yandeu/phaser-project-template-es6',
  'background: #ff0000',
  'background: #ffff00',
  'background: #00ff00',
  'background: #00ffff',
  'color: #fff; background: #000000;',
  'background: none'
)
